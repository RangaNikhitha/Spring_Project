package com.project.jdbc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.jdbc.model.Quote;
import com.project.jdbc.service.QuoteService;

@RestController
public class QuoteController {
	
	
	@Autowired
	private QuoteService quoteService;
	
	
	
	@PostMapping("/addQuote")
	public Quote addQuote(@RequestBody Quote quote) {
		return quoteService.saveDetails(quote);
	}
	
	@GetMapping("/Quotes")
	public List<Quote> getAllQuotes()
	{
		
		return quoteService.getAllDeatils();
	}

}

